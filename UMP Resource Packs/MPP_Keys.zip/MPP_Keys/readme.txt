You may already notice is that there are 3 folders named notePack. There are 3 variations for notes to be displayed during playback or rendering.

- Pack 1 was supposed to be the primary note set, but because of the lack of transparency handling, it doesn't display quite as expected.

- Pack 2 has the note set which is recommended for primary use of this resource pack. These should already be pasted into the main folder.

- Pack 3 has a note set which works best with a solid black background. This is best used for rendering videos.

By the way, please excuse that the keys are tall, as they were imported straight from Multiplayer Piano and no height adjustments were made to shorten them, for now anyway.

One more thing to mention, I also included an optional image you can place in front of the rendered video to make it look a bit more like Multiplayer Piano's keys.