[What was changed from the pre-release into the final?]

- Updated the readme.txt file to guide users through understanding the custom folders, including Key-Cover images.

- Created keypacks to allow the user to swap out the key's size whenever needed.

- Changed some notes to match accordingly in response to tiny note chains.

- Fixed a minor error with a noteEdge or two escaping checkup.

- Almost forgot to create a shorter Key-Cover before finally releasing.


[Multiplayer Piano Keys ver. 1.0]