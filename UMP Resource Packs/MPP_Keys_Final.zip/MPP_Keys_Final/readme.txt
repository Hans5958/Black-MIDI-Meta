Welcome! This is the finalized version of Multiplayer Piano Keys! Below are information that should be helpful when using this pack.

* Note Pack Folders *
These folders contain other variants of notes you can choose for display. If you already know about these folders, you can skip this part.

- Note Pack 1 contains notes that were orignally intended to be used for playback and rendering, but due to the lack of transparency handling, these will not display accordingly.

- Note Pack 2 contains notes you can use for both playback and rendering. These should already be pasted into the main folder.

- Note Pack 3 contains notes that is recommended only for rendering uses, specifically on a solid black background for the abovementioned reason in Pack 1.

* Key Pack Folders *
These folders contain two different sized keys you can choose for display.

- Key Pack 1 contains keys that were imported straight from Muliplayer Piano with no height adjustments. These should already be pasted into the main folder.

- Key Pack 2 contains keys that were modified to be shorter to match the height of normal keys such as Piano From Above's keys, or Synthesia's.

* Key-Cover Image (optional) *
Key-Covers (titled UMPMPPSkin.png) aim to make the keyboard look much more like Multiplayer Piano's keys when the notes strike the key.

These covers are found in either key pack folder depending on their height. If you have a video editor that supports transparency, place the cover in front of the render, so that only the intended square changes color instead of the whole key.


Demo Video: https://youtu.be/Qx0Yz2hYwqY