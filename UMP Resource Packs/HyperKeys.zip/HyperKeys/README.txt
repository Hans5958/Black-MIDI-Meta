Extract these files into /resourcepacks
I actually put some more effort into this skin than others tho :p